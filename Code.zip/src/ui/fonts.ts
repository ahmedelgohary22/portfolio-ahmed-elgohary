import { Montserrat, Open_Sans } from "next/font/google";

export const openSans = Open_Sans({ subsets: ["cyrillic", "latin"] });
export const montserrat = Montserrat({ subsets: ["cyrillic"] });
